/*
 * Estrutura de matérias e tópicos do edital PM-SC (Instituto AOCP).
 * Cada tópico corresponde a um material (PDF) dentro de materiais/.
 * Para adicionar um novo material: copie o PDF para a pasta materiais/
 * e adicione um objeto { id, titulo, arquivo, paginas } na lista "topicos"
 * da matéria correspondente (ou crie uma nova matéria).
 */
const MATERIAS = [
  {
    id: "portugues",
    nome: "Língua Portuguesa",
    topicos: [
      { id: "portugues-01", titulo: "Resumo completo", arquivo: "01-lingua-portuguesa.pdf", paginas: 49 }
    ]
  },
  {
    id: "informatica",
    nome: "Informática",
    topicos: [
      { id: "informatica-01", titulo: "Resumo completo", arquivo: "02-informatica.pdf", paginas: 41 }
    ]
  },
  {
    id: "direito-penal",
    nome: "Direito Penal",
    topicos: [
      { id: "direito-penal-01", titulo: "Resumo completo", arquivo: "03-direito-penal.pdf", paginas: 35 }
    ]
  },
  {
    id: "direito-constitucional",
    nome: "Direito Constitucional",
    topicos: [
      { id: "direito-constitucional-01", titulo: "Resumo completo", arquivo: "04-direito-constitucional.pdf", paginas: 41 }
    ]
  },
  {
    id: "direito-processual-penal",
    nome: "Direito Processual Penal",
    topicos: [
      { id: "direito-processual-penal-01", titulo: "Resumo completo", arquivo: "05-direito-processual-penal.pdf", paginas: 31 }
    ]
  },
  {
    id: "estatuto-pmsc",
    nome: "Estatuto dos Policiais Militares de SC",
    topicos: [
      { id: "estatuto-pmsc-01", titulo: "Resumo completo", arquivo: "06-estatuto-pmsc.pdf", paginas: 32 }
    ]
  },
  {
    id: "regulamento-disciplinar",
    nome: "Regulamento Disciplinar",
    topicos: [
      { id: "regulamento-disciplinar-01", titulo: "Resumo completo", arquivo: "07-regulamento-disciplinar.pdf", paginas: 32 }
    ]
  },
  {
    id: "lei-667",
    nome: "Lei 667/1969 (Reorganização da PM)",
    topicos: [
      { id: "lei-667-01", titulo: "Resumo completo", arquivo: "08-lei-667-1969.pdf", paginas: 11 }
    ]
  },
  {
    id: "direito-penal-militar",
    nome: "Direito Penal Militar",
    topicos: [
      { id: "direito-penal-militar-01", titulo: "Resumo completo", arquivo: "09-direito-penal-militar.pdf", paginas: 40 }
    ]
  },
  {
    id: "legislacao-transito",
    nome: "Legislação de Trânsito",
    topicos: [
      { id: "legislacao-transito-01", titulo: "Resumo completo", arquivo: "10-legislacao-transito.pdf", paginas: 40 }
    ]
  },
  {
    id: "legislacao-especial",
    nome: "Legislação Especial",
    topicos: [
      { id: "legislacao-especial-01", titulo: "Lei de Abuso de Autoridade", arquivo: "11-abuso-de-autoridade.pdf", paginas: 17 },
      { id: "legislacao-especial-02", titulo: "Lei de Drogas", arquivo: "12-lei-de-drogas.pdf", paginas: 21 },
      { id: "legislacao-especial-03", titulo: "Estatuto do Desarmamento", arquivo: "13-estatuto-desarmamento.pdf", paginas: 16 },
      { id: "legislacao-especial-04", titulo: "Lei Maria da Penha", arquivo: "14-maria-da-penha.pdf", paginas: 16 },
      { id: "legislacao-especial-05", titulo: "Juizados Especiais Criminais", arquivo: "15-juizados-especiais-criminais.pdf", paginas: 20 },
      { id: "legislacao-especial-06", titulo: "Crimes Hediondos", arquivo: "16-crimes-hediondos.pdf", paginas: 17 }
    ]
  }
];
