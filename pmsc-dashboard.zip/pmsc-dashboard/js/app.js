/* Painel de Estudos — PM-SC / AOCP
   Toda a persistência é feita em localStorage (funciona em qualquer
   hospedagem estática, sem precisar de banco de dados ou PHP).
   Use os botões "Exportar/Importar progresso" para levar o avanço
   de um dispositivo para outro. */

(function () {
  "use strict";

  const STORAGE_KEYS = {
    progress: "pmsc_progress_v1",
    examDate: "pmsc_exam_date_v1",
    metas: "pmsc_metas_v1"
  };

  // ---------- Storage helpers ----------

  function loadProgress() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.progress)) || {};
    } catch (e) { return {}; }
  }

  function saveProgress(progress) {
    localStorage.setItem(STORAGE_KEYS.progress, JSON.stringify(progress));
  }

  function loadExamDate() {
    return localStorage.getItem(STORAGE_KEYS.examDate) || "";
  }

  function saveExamDate(dateStr) {
    if (dateStr) localStorage.setItem(STORAGE_KEYS.examDate, dateStr);
    else localStorage.removeItem(STORAGE_KEYS.examDate);
  }

  function loadMetas() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.metas)) || [];
    } catch (e) { return []; }
  }

  function saveMetas(metas) {
    localStorage.setItem(STORAGE_KEYS.metas, JSON.stringify(metas));
  }

  let progress = loadProgress();
  let metas = loadMetas();

  // ---------- Toast ----------

  let toastTimer = null;
  function showToast(msg) {
    const toast = document.getElementById("toast");
    toast.textContent = msg;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2400);
  }

  // ---------- Ícones ----------

  const ICON_OPEN = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6"/><path d="M10 14 21 3"/></svg>';
  const ICON_CHECK = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M20 6 9 17l-5-5"/></svg>';
  const ICON_CHEVRON = '<svg class="materia-chevron" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m6 9 6 6 6-6"/></svg>';

  // ---------- Render matérias ----------

  const grid = document.getElementById("materias-grid");
  const materiasAbertas = new Set();

  function countTopicos() {
    let total = 0;
    MATERIAS.forEach(m => { total += m.topicos.length; });
    return total;
  }

  function countTopicosFeitos() {
    let feitos = 0;
    MATERIAS.forEach(m => m.topicos.forEach(t => { if (progress[t.id]) feitos++; }));
    return feitos;
  }

  function materiaCompleta(materia) {
    return materia.topicos.every(t => progress[t.id]);
  }

  function materiaFeitos(materia) {
    return materia.topicos.filter(t => progress[t.id]).length;
  }

  function renderMaterias() {
    grid.innerHTML = "";

    MATERIAS.forEach(materia => {
      const feitos = materiaFeitos(materia);
      const totalTopicos = materia.topicos.length;
      const pct = totalTopicos ? Math.round((feitos / totalTopicos) * 100) : 0;
      const completa = feitos === totalTopicos;

      const aberta = materiasAbertas.has(materia.id);
      const card = document.createElement("div");
      card.className = "materia-card" + (completa ? " complete" : "") + (aberta ? " open" : "");
      card.dataset.materiaId = materia.id;

      const header = document.createElement("button");
      header.type = "button";
      header.className = "materia-header";
      header.innerHTML = `
        <div class="materia-top">
          <span class="materia-nome">${materia.nome}</span>
          ${ICON_CHEVRON}
        </div>
        <div class="materia-meta">${feitos}/${totalTopicos} tópicos · ${pct}%</div>
        <div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div>
      `;
      header.addEventListener("click", () => {
        if (materiasAbertas.has(materia.id)) materiasAbertas.delete(materia.id);
        else materiasAbertas.add(materia.id);
        card.classList.toggle("open");
      });

      const list = document.createElement("ul");
      list.className = "topicos-list";

      materia.topicos.forEach(topico => {
        const done = !!progress[topico.id];
        const li = document.createElement("li");
        li.className = "topico-item" + (done ? " done" : "");
        li.innerHTML = `
          <div class="topico-info">
            <div class="topico-titulo">${topico.titulo}</div>
            <div class="topico-paginas">${topico.paginas} pág.</div>
          </div>
          <div class="topico-actions">
            <a class="icon-btn" href="materiais/${encodeURIComponent(topico.arquivo)}" target="_blank" rel="noopener" title="Abrir material">${ICON_OPEN}</a>
            <button type="button" class="toggle-studied${done ? " done" : ""}" data-topico-id="${topico.id}">
              ${done ? ICON_CHECK + " Estudado" : "Marcar como estudado"}
            </button>
          </div>
        `;
        list.appendChild(li);
      });

      card.appendChild(header);
      card.appendChild(list);
      grid.appendChild(card);
    });

    grid.querySelectorAll(".toggle-studied").forEach(btn => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const id = btn.dataset.topicoId;
        progress[id] = !progress[id];
        saveProgress(progress);
        renderMaterias();
        renderKpis();
      });
    });
  }

  // ---------- KPIs ----------

  function renderKpis() {
    const totalTopicos = countTopicos();
    const feitosTopicos = countTopicosFeitos();
    const totalMaterias = MATERIAS.length;
    const materiasFeitas = MATERIAS.filter(materiaCompleta).length;
    const pct = totalTopicos ? Math.round((feitosTopicos / totalTopicos) * 100) : 0;

    document.getElementById("kpi-progresso").textContent = pct + "%";
    document.getElementById("kpi-progresso-sub").textContent = `${feitosTopicos} de ${totalTopicos} tópicos`;
    document.getElementById("kpi-materias").textContent = `${materiasFeitas}/${totalMaterias}`;
    document.getElementById("kpi-topicos").textContent = `${feitosTopicos}/${totalTopicos}`;
  }

  // ---------- Contagem regressiva ----------

  const elCountdownSet = document.getElementById("countdown-set");
  const elCountdownUnset = document.getElementById("countdown-unset");
  const elCountdownBig = document.getElementById("countdown-big");
  const elCountdownLabel = document.getElementById("countdown-label");
  const elKpiDias = document.getElementById("kpi-dias");
  const elKpiDiasSub = document.getElementById("kpi-dias-sub");
  const inputDataProva = document.getElementById("input-data-prova");
  const btnLimparData = document.getElementById("btn-limpar-data");

  function renderCountdown() {
    const dateStr = loadExamDate();

    if (!dateStr) {
      elCountdownSet.classList.add("hidden");
      elCountdownUnset.classList.remove("hidden");
      btnLimparData.classList.add("hidden");
      elKpiDias.textContent = "—";
      elKpiDiasSub.textContent = "data ainda não definida";
      return;
    }

    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    const prova = new Date(dateStr + "T00:00:00");
    const diffMs = prova - hoje;
    const diffDias = Math.ceil(diffMs / 86400000);

    elCountdownSet.classList.remove("hidden");
    elCountdownUnset.classList.add("hidden");
    btnLimparData.classList.remove("hidden");
    inputDataProva.value = dateStr;

    const dataFmt = prova.toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" });

    if (diffDias > 0) {
      elCountdownBig.textContent = diffDias;
      elCountdownLabel.textContent = `dias até a prova (${dataFmt})`;
      elKpiDias.textContent = diffDias;
      elKpiDiasSub.textContent = dataFmt;
    } else if (diffDias === 0) {
      elCountdownBig.textContent = "Hoje!";
      elCountdownLabel.textContent = `é dia de prova (${dataFmt})`;
      elKpiDias.textContent = "0";
      elKpiDiasSub.textContent = "é hoje!";
    } else {
      elCountdownBig.textContent = "—";
      elCountdownLabel.textContent = `prova realizada em ${dataFmt}`;
      elKpiDias.textContent = "0";
      elKpiDiasSub.textContent = dataFmt;
    }
  }

  document.getElementById("form-data-prova").addEventListener("submit", (e) => {
    e.preventDefault();
    const val = inputDataProva.value;
    if (!val) return;
    saveExamDate(val);
    renderCountdown();
    showToast("Data da prova salva.");
  });

  btnLimparData.addEventListener("click", () => {
    saveExamDate("");
    inputDataProva.value = "";
    renderCountdown();
    showToast("Data removida.");
  });

  // ---------- Metas ----------

  const metasList = document.getElementById("metas-list");
  const metasEmpty = document.getElementById("metas-empty");

  function renderMetas() {
    metasList.innerHTML = "";

    if (!metas.length) {
      metasEmpty.classList.remove("hidden");
      return;
    }
    metasEmpty.classList.add("hidden");

    const ordenadas = [...metas].sort((a, b) => {
      if (a.done !== b.done) return a.done ? 1 : -1;
      if (a.data && b.data) return a.data.localeCompare(b.data);
      if (a.data) return -1;
      if (b.data) return 1;
      return 0;
    });

    ordenadas.forEach(meta => {
      const li = document.createElement("li");
      li.className = "meta-item" + (meta.done ? " done" : "");
      const dataFmt = meta.data ? new Date(meta.data + "T00:00:00").toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" }) : "";
      li.innerHTML = `
        <button type="button" class="meta-check" data-meta-id="${meta.id}" title="Marcar como concluída">${meta.done ? ICON_CHECK : ""}</button>
        <span class="meta-text">${escapeHtml(meta.texto)}</span>
        ${dataFmt ? `<span class="meta-date">${dataFmt}</span>` : ""}
        <button type="button" class="meta-remove" data-meta-id="${meta.id}" title="Remover">×</button>
      `;
      metasList.appendChild(li);
    });

    metasList.querySelectorAll(".meta-check").forEach(btn => {
      btn.addEventListener("click", () => {
        const meta = metas.find(m => m.id === btn.dataset.metaId);
        if (meta) {
          meta.done = !meta.done;
          saveMetas(metas);
          renderMetas();
        }
      });
    });

    metasList.querySelectorAll(".meta-remove").forEach(btn => {
      btn.addEventListener("click", () => {
        metas = metas.filter(m => m.id !== btn.dataset.metaId);
        saveMetas(metas);
        renderMetas();
      });
    });
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  document.getElementById("form-meta").addEventListener("submit", (e) => {
    e.preventDefault();
    const inputTexto = document.getElementById("input-meta-texto");
    const inputData = document.getElementById("input-meta-data");
    const texto = inputTexto.value.trim();
    if (!texto) return;

    metas.push({
      id: "m" + Date.now() + Math.random().toString(36).slice(2, 7),
      texto,
      data: inputData.value || "",
      done: false
    });
    saveMetas(metas);
    inputTexto.value = "";
    inputData.value = "";
    renderMetas();
  });

  // ---------- Exportar / Importar progresso ----------

  document.getElementById("btn-export").addEventListener("click", () => {
    const payload = {
      tipo: "pmsc-dashboard-progresso",
      versao: 1,
      exportadoEm: new Date().toISOString(),
      progress,
      examDate: loadExamDate(),
      metas
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "pmsc-progresso.json";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast("Progresso exportado.");
  });

  const btnImport = document.getElementById("btn-import");
  const inputImport = document.getElementById("input-import");

  btnImport.addEventListener("click", () => inputImport.click());

  inputImport.addEventListener("change", () => {
    const file = inputImport.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (data.tipo !== "pmsc-dashboard-progresso") throw new Error("arquivo inválido");

        progress = data.progress || {};
        metas = data.metas || [];
        saveProgress(progress);
        saveMetas(metas);
        saveExamDate(data.examDate || "");

        renderMaterias();
        renderKpis();
        renderCountdown();
        renderMetas();
        showToast("Progresso importado com sucesso.");
      } catch (err) {
        showToast("Não foi possível importar esse arquivo.");
      }
      inputImport.value = "";
    };
    reader.readAsText(file);
  });

  // ---------- Init ----------

  renderMaterias();
  renderKpis();
  renderCountdown();
  renderMetas();

})();
